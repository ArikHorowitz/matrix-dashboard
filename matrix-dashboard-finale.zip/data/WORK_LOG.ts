export const WORK_LOGS: string[] = [
  "Align epistemic tone across all chapters in Part II.",
  "Flag institutional tension and its consequences in Chapter 13 vs 14.",
  "Embed lyric excerpt or poetic fragment in Chapter 1's artistic lens.",
  "Review the transition from 'Trauma' (Part 3) to 'Recovery' (Part 4).",
  "Ensure 'Motif' tracker correctly captures the shift from Obedience to Volition."
];
